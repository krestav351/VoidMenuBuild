# Void Menu — Android project

A standalone purple-themed Android UI prototype for ARM64 devices. It does not modify or inject into Oxide: Survival Island and does not implement aim assistance, hidden-player ESP/X-ray, or anti-cheat bypass.

## Build APK
1. Open this folder in Android Studio (recent version).
2. Install Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle version if prompted.
3. Use **Build > Build APK(s)**.
4. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.voidmenu.demo` · min Android 6.0 (API 23) · target API 35.
