package com.voidmenu.demo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    final int bg = Color.rgb(16,11,24), panel = Color.rgb(29,20,43), purple = Color.rgb(139,92,246), white = Color.rgb(245,238,255), muted = Color.rgb(184,164,210);
    LinearLayout root, content, tabs; String active = "VISUALS";
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    GradientDrawable shape(int color, int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root=column(); root.setBackgroundColor(bg); pad(root,18,16,18,20); scroll.addView(root); setContentView(scroll);
        LinearLayout header=row(); TextView logo=text("✦",27,white,true); logo.setGravity(Gravity.CENTER); logo.setBackground(shape(purple,14)); header.addView(logo,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout title=column(); pad(title,12,0,0,0); title.addView(text("VOID MOD MENU",20,white,true)); title.addView(text("OXIDE · SURVIVAL ISLAND",11,muted,true)); header.addView(title,new LinearLayout.LayoutParams(0,dp(54),1));
        TextView chip=text("ARM64",11,white,true); chip.setGravity(Gravity.CENTER); chip.setBackground(shape(Color.rgb(61,42,85),16)); pad(chip,12,7,12,7); header.addView(chip); root.addView(header); space(root,20);
        LinearLayout card=column(); card.setBackground(shape(panel,20)); pad(card,16,16,16,18); root.addView(card);
        TextView note=text("DEMO WORKSPACE",11,muted,true); card.addView(note); space(card,8); card.addView(text("Visual settings & test scene",18,white,true)); space(card,5); card.addView(text("Standalone interface · no key or account required",12,muted,false)); space(card,18);
        tabs=row(); tabs.setBackground(shape(bg,14)); card.addView(tabs); addTab("VISUALS"); addTab("AIM"); addTab("SCENE"); space(card,16);
        content=column(); card.addView(content); render(); space(root,14);
        TextView foot=text("UI prototype only — no game process access, player tracking, or anti-cheat bypass.",11,muted,false); root.addView(foot);
    }
    void space(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    void addTab(String name){ TextView t=text(name,11,active.equals(name)?white:muted,true); t.setGravity(Gravity.CENTER); pad(t,6,12,6,12); t.setBackground(shape(active.equals(name)?purple:bg,12)); tabs.addView(t,new LinearLayout.LayoutParams(0,dp(42),1)); t.setOnClickListener(v->{active=name; for(int i=0;i<tabs.getChildCount();i++){TextView x=(TextView)tabs.getChildAt(i); String n=new String[]{"VISUALS","AIM","SCENE"}[i]; x.setBackground(shape(active.equals(n)?purple:bg,12)); x.setTextColor(active.equals(n)?white:muted);} render();}); }
    void section(String s){ TextView t=text(s,13,Color.rgb(216,180,254),true); content.addView(t); space(content,8); }
    void toggle(String name,String desc,boolean checked){ LinearLayout r=row(); pad(r,0,7,0,7); LinearLayout c=column(); c.addView(text(name,14,white,true)); c.addView(text(desc,11,muted,false)); r.addView(c,new LinearLayout.LayoutParams(0,dp(54),1)); Switch sw=new Switch(this); sw.setButtonTintList(null); sw.setChecked(checked); r.addView(sw); content.addView(r); }
    void slider(String name,int max,int value,String suffix){ content.addView(text(name,13,white,true)); SeekBar s=new SeekBar(this); s.setMax(max); s.setProgress(value); s.setProgressTintList(android.content.res.ColorStateList.valueOf(purple)); s.setThumbTintList(android.content.res.ColorStateList.valueOf(white)); content.addView(s); TextView val=text(value+suffix,11,muted,false); content.addView(val); s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){val.setText(p+suffix);} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}}); space(content,12); }
    void render(){ content.removeAllViews(); if(active.equals("VISUALS")){section("VISUALIZATION");toggle("ESP preview","Show mock objects in the test scene",true);toggle("Object labels","Display names and distance in demo",true);toggle("Outline effect","Purple outline in local scene",false);space(content,12);slider("Preview range",200,80," m");}
      else if(active.equals("AIM")){section("AIM UI SETTINGS");toggle("Aim settings panel","Controls only; not connected to a game",true);slider("Capture radius",200,80," px");slider("Aim strength",100,50,"%");toggle("Head marker (demo)","Marker in the local test scene only",false);}
      else {section("LOCAL TEST SCENE");toggle("Show sample targets","Draw built-in placeholder shapes",true);toggle("Occlusion visualization","Illustrate visible / hidden test objects",false);TextView info=text("This standalone prototype has no permissions to inspect or modify another game's memory, network traffic, or player state.",12,muted,false); pad(info,0,8,0,8); content.addView(info);}
    }
}
